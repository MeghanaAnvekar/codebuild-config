const library = require('./library');
data = "1\n2\n3\n4"
console.log(library.calculateSquares(data));
