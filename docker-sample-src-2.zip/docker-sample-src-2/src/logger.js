function log(message){
    console.log('[INFO] ' + message )
}

module.exports.log = log;
